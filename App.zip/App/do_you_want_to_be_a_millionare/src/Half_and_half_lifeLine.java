public class Half_and_half_lifeLine {
  static void fiftyFifty(String[] a) {
    System.out.println(a[2] + " is incorrect");
    System.out.println(a[3] + " is incorrect");
    System.out.println("You cannot use this hint anymore!");
  }
}
